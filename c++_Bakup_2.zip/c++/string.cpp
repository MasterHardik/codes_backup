#include<iostream>
#include<string>

using namespace std;

int ()
{
	string str;
	cin>>str;
	cout<<str;
	return 0;
}