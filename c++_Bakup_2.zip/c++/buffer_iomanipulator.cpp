#include <stdio.h>
#include <iomanip>
using namespace std;

int main()
{
    char buf[10];
    cin >> std::setw(10) >> buf;
    return 0;
}