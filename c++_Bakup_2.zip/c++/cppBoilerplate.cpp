#include<bits/stdc++.h>
#define ll long long
#define MAX INT_MIN
#define MIN INT_MAX
using namespace std;

void init_code() {
#ifndef ONLINE_JUDGE
freopen("Input.txt", "r", stdin);
freopen("Output.txt", "w", stdout);
#endif
}

int main()
{
	init_code();
	
	// logic here

	return 0;
}