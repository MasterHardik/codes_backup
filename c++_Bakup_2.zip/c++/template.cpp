#include<bits/stdc++.h>
#define ll long long
#define MAX INT_MIN
#define MIN INT_MAX
using namespace std;

void init_code() {
#ifndef ONLINE_JUDGE
freopen("Input.txt", "r", stdin);
freopen("Output.txt", "w", stdout);
#endif // ONLINE_JUDGE
}

int main()
{
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
	init_code();     // must call this to use
	int t;
	cin>>t;
	while(t--){
		// logic here
	}
	for(int i=0;i<n;i++){
		// logic here
	}
	return 0;
}