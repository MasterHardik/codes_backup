#include<bits/stdc++.h>
using namespace std;
int main()
{
    vector<string>ans;
     sort(ans.begin(), ans.end());
    return 0;
}
