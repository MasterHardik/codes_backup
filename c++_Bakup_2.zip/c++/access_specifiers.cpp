#include<iostream>

using namespace std;

class add{// by defailt private members.
public: 
	int a;
	int b;	
};

int main()
{
	add a1;
	a1.a = 5;
	a1.b = 3;

	return 0;
}


//jargons -->> technical terminologies
/*
 * Class is a description of object 
 * Object is an instance of a class
 */