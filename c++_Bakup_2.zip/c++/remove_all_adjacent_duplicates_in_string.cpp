#include <iostream>
#include <stack>
using namespace std;

int main()
{
    string s;
    cin >> s;
    int k;
    cin >> k;
    return 0;
}