#include<bits/stdc++.h>
using namespace std;

int main()
{
	cout <<1<<endl;
	return 0;
}


// {
// 	// "shell_cmd": "make"
// 	"cmd": ["g++.exe",
// 		"-std=c++17", "${file}",
// 		"-o",
// 		"${file_base_name}.exe<Input.txt>Output.txt"],
// 	"shell":true,
// 	"working_dir":"$file_path",
// 	"selector":"source.cpp"
// }



// first save the above code in a tools->build system -> new  build system then save it with the name CPP1  

// reference from YT: Priyansh Agrawal