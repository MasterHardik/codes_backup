#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int num;
    cin >> num;
    to
    return 0;
}
