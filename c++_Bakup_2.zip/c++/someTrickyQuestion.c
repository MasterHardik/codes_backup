
#include<stdio.h>
//#1

// int main(int argc, char const *argv[])
// {
//     if(sizeof(int) > -1 )
//         printf("True\n");
//     else 
//         printf("False\n");
//     return 0;
// }

//#2

// int main(int argc, char const *argv[])
// {
//     float f = 0.1;

//     if(f == 0.1)
//         printf("True\n");
//     else 
//         printf("False\n");

//     return 0;
// }

//#3

// int main()
// {
//     int a,b=1,c=1;

//     a=sizeof(c = ++b + 1);
//     printf("a=%d,b=%d,c+%d\n",a,b,c);
//     return 0;
// }

//#4
// int main(){
//     char *p=0;

//     *p = 'A';
//     printf("Vale at p=%c\n",*p);
// }

//#5
// int main(int argc, char const *argv[])
// {
//     int a=1,b=3,c=2;
//     if(a>b)
//         if(b>c)
//             printf("a>b and  b>c \n");
//     else 
//         printf("something else\n");
//     return 0;
// }
