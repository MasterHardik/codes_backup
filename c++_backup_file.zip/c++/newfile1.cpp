#include<iostream>

using namespace std;
int main(int argc, char const *argv[])
{
	cout<<"Our first program isworking  fine";
	return 0;
}