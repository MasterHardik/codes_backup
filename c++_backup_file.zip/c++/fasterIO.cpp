#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);   //  boosts faster I/O and can be used inspite of priintf or scanf 
    cin.tie(NULL);                      //  tie efunction helps to flush the ostream 
                                        //  before the new input could be taken
    return 0;
}