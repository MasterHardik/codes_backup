#include<bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
    cout<<"Working"<<endl;
    return 0;
}
