#include<iostream>

using namespace std;

class complex
{
public:
	int a,b;
public:
	complex(int x, int y)//  constructor -> basically function
	{a=x ; b=y;}

	complex(int x)  //parametrized constructor
	{ }
};

int main(int argc, char const *argv[])
{
	complex c1(2,3)	;
	complex c2;
	return 0;
}
