#include<iostream>

using namespace std;

void pattern6(int n){
	
}

int main(int argc, char const *argv[])
{
	pattern6();
	return 0;
}