#include <bits/stdc++.h>

using namespace std;

int main()
{
    unordered_map<string, vector<string>> umap;
    return 0;
}

/*
 * Anagrams are words that have meaning ee=ven after letters rearrange ment
 * like : ate -> eat , tea , eta , tae  etc;
 */