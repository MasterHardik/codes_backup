#include<iostream>

using namespace std;

void init_code()
{
	#ifndef ONLINE_JUDE
	freopen("Input.txt","r",stdin);
	freopen("Output.txt","w",stdout);
	#endif
}

int main()
{
	init_code();
	// // int n;
	// // cin>>n;
	// // while(n--)
	// // {
	// // }
	cout<<"-->>"<<endl;
	return 0;
}