#include<iostream>


int main(int argc, char const *argv[])
{
	std::cout<<"\U0001F600"; // 😀
	return 0;
}